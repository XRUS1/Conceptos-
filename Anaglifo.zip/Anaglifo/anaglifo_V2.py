#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Diseno Interactivo - Pop-Up Anaglifo
Open3D (nube de puntos + malla triangular) + mpl_stereo (Dubois)
Papel recomendado: Astrobrights 65 lb smooth
Modelo: LiheYoung/depth-anything-small-hf (profundidad relativa)
"""

import os
import numpy as np
from PIL import Image
from transformers import pipeline
import open3d as o3d
from mpl_stereo import AxesAnaglyph


# ------------------------------------------------------------------
# CONFIGURACION
# ------------------------------------------------------------------
RUTA_FOTO = "entrada.jpg"
SALIDA_ANAGLIFO = "pared_pop_up.png"
SALIDA_NUBE = "01_nube_puntos.ply"
SALIDA_MALLA = "02_malla_superficie.ply"

RES_RENDER = (2400, 1800)
BASELINE = 0.035
DPI = 300
VOXEL_SIZE = 0.012


# ------------------------------------------------------------------
# 1. NUBE DE PUNTOS (Open3D)
# ------------------------------------------------------------------
def foto_a_nube(ruta: str):
    print("PASO 1: Estimando profundidad monocular...")
    img = Image.open(ruta).convert("RGB")
    ancho, alto = img.size

    pipe = pipeline(
        task="depth-estimation",
        model="LiheYoung/depth-anything-small-hf",
        device=-1
    )
    prof = pipe(img)["depth"].resize((ancho, alto))

    color_np = np.array(img)
    depth_np = np.array(prof).astype(np.float32)

    # CORRECCION CRITICA: Depth-Anything devuelve 0=farther, 255=closest.
    # Open3D espera la convencion opuesta (0=closest, 255=farther).
    # Sin esta inversion, el anaglifo tiene profundidad invertida.
    depth_np = 255.0 - depth_np

    rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
        o3d.geometry.Image(color_np),
        o3d.geometry.Image(depth_np),
        depth_scale=255.0,
        depth_trunc=3.0,
        convert_rgb_to_intensity=False
    )

    fx = fy = max(ancho, alto)
    intrinseca = o3d.camera.PinholeCameraIntrinsic(
        ancho, alto, fx, fy, ancho / 2, alto / 2
    )

    pcd = o3d.geometry.PointCloud.create_from_rgbd_image(rgbd, intrinseca)
    pcd.transform([[1, 0, 0, 0],
                   [0, -1, 0, 0],
                   [0, 0, -1, 0],
                   [0, 0, 0, 1]])

    print("PASO 2: Filtrado estadistico y downsampling...")
    pcd, _ = pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
    pcd = pcd.voxel_down_sample(voxel_size=VOXEL_SIZE)

    colores = np.asarray(pcd.colors)
    if colores.size > 0 and colores.max() > 1.0:
        pcd.colors = o3d.utility.Vector3dVector(colores / 255.0)

    o3d.io.write_point_cloud(SALIDA_NUBE, pcd)
    print(f"  Guardado: {SALIDA_NUBE} ({len(pcd.points)} puntos)")
    return pcd


# ------------------------------------------------------------------
# 2. MALLA TRIANGULAR (Open3D)
# ------------------------------------------------------------------
def nube_a_malla(pcd):
    print("PASO 3: Reconstruccion de superficie (Ball Pivoting)...")
    pcd.estimate_normals(
        search_param=o3d.geometry.KDTreeSearchParamHybrid(
            radius=VOXEL_SIZE * 2, max_nn=30
        )
    )

    k = min(100, max(10, len(pcd.points) - 1))
    if k > 0:
        pcd.orient_normals_consistent_tangent_plane(k)

    radii = [VOXEL_SIZE * 1.5, VOXEL_SIZE * 3, VOXEL_SIZE * 6]
    malla = o3d.geometry.TriangleMesh.create_from_point_cloud_ball_pivoting(
        pcd, o3d.utility.DoubleVector(radii)
    )

    if len(malla.triangles) == 0:
        raise RuntimeError("Ball Pivoting no genero triangulos.")

    malla.vertex_colors = pcd.colors
    malla = malla.filter_smooth_laplacian(number_of_iterations=3)
    malla.remove_degenerate_triangles()
    malla.remove_unreferenced_vertices()

    o3d.io.write_triangle_mesh(SALIDA_MALLA, malla)
    print(f"  Guardado: {SALIDA_MALLA} ({len(malla.triangles)} triangulos)")
    return malla


# ------------------------------------------------------------------
# 3. RENDER ESTEREO OFF-SCREEN (Open3D)
# ------------------------------------------------------------------
def renderizar(malla, offset_x, res):
    vis = o3d.visualization.Visualizer()
    try:
        vis.create_window(visible=False, width=res[0], height=res[1])
    except RuntimeError as e:
        raise RuntimeError(
            "Open3D no puede crear ventana off-screen. "
            "En Linux/headless: sudo apt-get install libosmesa6-dev"
        ) from e

    vis.add_geometry(malla)

    opt = vis.get_render_option()
    opt.background_color = np.asarray([1.0, 1.0, 1.0])
    opt.mesh_show_back_face = True
    opt.light_on = True

    ctr = vis.get_view_control()
    cam = ctr.convert_to_pinhole_camera_parameters()
    cam.extrinsic[0, 3] += offset_x
    ctr.convert_from_pinhole_camera_parameters(cam)

    vis.poll_events()
    vis.update_renderer()
    img = vis.capture_screen_float_buffer(do_render=True)
    vis.destroy_window()
    return np.asarray(img)


# ------------------------------------------------------------------
# 4. ANAGLIFO DUBOIS (mpl_stereo)
# ------------------------------------------------------------------
def componer_anaglifo(img_izq, img_der):
    print("PASO 4: Componiendo anaglifo Dubois...")

    ax = AxesAnaglyph()
    ax.imshow_stereo([img_izq, img_der])

    try:
        ax.save(SALIDA_ANAGLIFO, plot_area=True, dpi=DPI)
    except TypeError:
        ax.fig.savefig(SALIDA_ANAGLIFO, dpi=DPI, bbox_inches="tight", pad_inches=0)
        print("  (usado matplotlib.savefig como fallback)")

    print(f"  Guardado: {SALIDA_ANAGLIFO}")
    print(f"  Dimension impresa: {RES_RENDER[0]/DPI:.1f} x {RES_RENDER[1]/DPI:.1f} pulgadas")


# ------------------------------------------------------------------
# EJECUCION
# ------------------------------------------------------------------
def main():
    if not os.path.exists(RUTA_FOTO):
        raise FileNotFoundError(f"No se encontro: {RUTA_FOTO}")

    pcd = foto_a_nube(RUTA_FOTO)
    malla = nube_a_malla(pcd)

    print("PASO 5: Renderizando vistas izquierda y derecha...")
    izq = renderizar(malla, -BASELINE / 2, RES_RENDER)
    der = renderizar(malla, +BASELINE / 2, RES_RENDER)

    componer_anaglifo(izq, der)

    print("\nArchivos generados:")
    print(f"  {SALIDA_NUBE}     -> Nube de puntos (tema de clase)")
    print(f"  {SALIDA_MALLA} -> Malla triangular (tema de clase)")
    print(f"  {SALIDA_ANAGLIFO}   -> Imagen para impresion pop-up")


if __name__ == "__main__":
    main()
