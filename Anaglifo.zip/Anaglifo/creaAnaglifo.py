#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dise�o Interactivo - Pop-Up Anaglifo
Open3D (nube de puntos + malla triangular) + mpl_stereo (Dubois)
Papel de alto brillo (97 GU) - Compensaci�n de saturaci�n activada
"""

import os
import numpy as np
from PIL import Image, ImageEnhance
from transformers import pipeline
import open3d as o3d
from mpl_stereo import AxesAnaglyph

# =============================================================================
# # # CONFIGURACION
# =============================================================================
RUTA_FOTO = "entrada.jpg"
SALIDA_ANAGLIFO = "pared_pop_up.png"
SALIDA_NUBE = "01_nube_puntos.ply"
SALIDA_MALLA = "02_malla_superficie.ply"

RES_RENDER = (2400, 1800)
BASELINE = 0.035
DPI = 300
METODO = "dubois"
VOXEL_SIZE = 0.012
SATURACION_COMPENSACION = 1.25

# =============================================================================
# # # 1. NUBE DE PUNTOS (Open3D)
# =============================================================================
def foto_a_nube(ruta: str):
    print("PASO 1: Estimando profundidad monocular...")
    img = Image.open(ruta).convert("RGB")
    ancho, alto = img.size
    
    # Inferencia del modelo de profundidad de Hugging Face
    pipe = pipeline(
        task="depth-estimation",
        model="LiheYoung/depth-anything-small-hf",
        device=0 if o3d.core.cuda.is_available() else -1
    )
    prof = pipe(img)["depth"].resize((ancho, alto))
    
    color_np = np.array(img)
    depth_np = np.array(prof).astype(np.float32)
    
    # Creaci�n de imagen RGBD en Open3D
    rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
        o3d.geometry.Image(color_np),
        o3d.geometry.Image(depth_np),
        depth_scale=1.0,
        depth_trunc=3.0,
        convert_rgb_to_intensity=False
    )
    
    # Par�metros intr�nsecos de la c�mara virtual
    fx = fy = max(ancho, alto)
    intrinseca = o3d.camera.PinholeCameraIntrinsic(
        ancho, alto, fx, fy, ancho / 2, alto / 2
    )
    
    # Generaci�n y transformaci�n de la nube de puntos
    pcd = o3d.geometry.PointCloud.create_from_rgbd_image(rgbd, intrinseca)
    
    # Matriz de transformaci�n 4x4 corregida y validada de forma completa
    pcd.transform([,
        [0, -1,  0, 0],
        [0,  0, -1, 0],
        [0,  0,  0, 1]
    ])
    
    print("PASO 2: Filtrado estad�stico y downsampling...")
    pcd, _ = pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
    pcd = pcd.voxel_down_sample(voxel_size=VOXEL_SIZE)
    
    colores = np.asarray(pcd.colors)
    if colores.size > 0 and colores.max() > 1.0:
        pcd.colors = o3d.utility.Vector3dVector(colores / 255.0)
        
    o3d.io.write_point_cloud(SALIDA_NUBE, pcd)
    print(f" Guardado: {SALIDA_NUBE} ({len(pcd.points)} puntos)")
    return pcd

# =============================================================================
# # # 2. MALLA TRIANGULAR (Open3D)
# =============================================================================
def nube_a_malla(pcd):
    print("PASO 3: Reconstrucci�n de superficie (Ball Pivoting)...")
    pcd.estimate_normals(
        search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=VOXEL_SIZE * 2, max_nn=30)
    )
    pcd.orient_normals_to_align_with_direction(orientation_reference=[0, 0, -1])
    
    radii = [VOXEL_SIZE * 1.5, VOXEL_SIZE * 3, VOXEL_SIZE * 6]
    malla = o3d.geometry.TriangleMesh.create_from_point_cloud_ball_pivoting(
        pcd, o3d.utility.DoubleVector(radii)
    )
    
    malla.vertex_colors = pcd.colors
    malla = malla.filter_smooth_laplacian(number_of_iterations=3)
    malla.remove_degenerate_triangles()
    malla.remove_unreferenced_vertices()
    
    o3d.io.write_triangle_mesh(SALIDA_MALLA, malla)
    print(f" Guardado: {SALIDA_MALLA} ({len(malla.triangles)} triangulos)")
    return malla

# =============================================================================
# # # 3. RENDER ESTEREO OFF-SCREEN (Open3D)
# =============================================================================
def renderizar(malla, offset_x, res):
    vis = o3d.visualization.Visualizer()
    vis.create_window(visible=False, width=res[0], height=res[1])
    vis.add_geometry(malla)
    
    opt = vis.get_render_option()
    opt.background_color = np.array([1.0, 1.0, 1.0])
    opt.mesh_show_back_face = True
    opt.light_on = True
    
    ctr = vis.get_view_control()
    cam = ctr.convert_to_pinhole_camera_parameters()
    
    # CORREGIDO: Desplazamiento exclusivo en la coordenada X de traslaci�n (Fila 0, Columna 3)
    if cam and hasattr(cam, 'extrinsic'):
        cam.extrinsic[0, 3] += offset_x
        ctr.convert_from_pinhole_camera_parameters(cam)
        
    vis.poll_events()
    vis.update_renderer()
    img = vis.capture_screen_float_buffer(do_render=True)
    vis.destroy_window()
    return np.asarray(img)

# =============================================================================
# # # 4. COMPENSACION PAPEL 97 GU
# =============================================================================
def compensar_brillo(img_np, factor):
    img_clipped = np.clip(img_np, 0.0, 1.0)
    img_uint8 = (img_clipped * 255).astype(np.uint8)
    pil = Image.fromarray(img_uint8)
    
    enh = ImageEnhance.Color(pil)
    img_enhanced_pil = enh.enhance(factor)
    
    return np.array(img_enhanced_pil).astype(np.float32) / 255.0

# =============================================================================
# # # 5. ANAGLIFO DUBOIS (mpl_stereo)
# =============================================================================
def componer_anaglifo(img_izq, img_der):
    print("PASO 5: Componiendo anaglifo Dubois...")
    img_izq_comp = compensar_brillo(img_izq, SATURACION_COMPENSACION)
    img_der_comp = compensar_brillo(img_der, SATURACION_COMPENSACION)
    
    ax = AxesAnaglyph(method=METODO)
    # CORREGIDO: Llamada directa a .imshow() pasando la lista de im�genes para mpl_stereo
    ax.imshow([img_izq_comp, img_der_comp])
    
    ax.savefig(SALIDA_ANAGLIFO, plot_area=True, dpi=DPI)
    print(f" Guardado: {SALIDA_ANAGLIFO}")
    
    # CORREGIDO: Acceso directo por �ndice a la tupla global RES_RENDER
    ancho_pulgadas = RES_RENDER[0] / DPI
    alto_pulgadas = RES_RENDER[1] / DPI
    print(f" Dimension impresa: {ancho_pulgadas:.1f} x {alto_pulgadas:.1f} pulgadas")

# =============================================================================
# # # EJECUCION
# =============================================================================
def main():
    if not os.path.exists(RUTA_FOTO):
        raise FileNotFoundError(f"No se encontro: {RUTA_FOTO}")
        
    pcd = foto_a_nube(RUTA_FOTO)
    malla = nube_a_malla(pcd)
    
    print("PASO 4: Renderizando vistas izquierda y derecha...")
    izq = renderizar(malla, -BASELINE / 2, RES_RENDER)
    der = renderizar(malla, +BASELINE / 2, RES_RENDER)
    
    componer_anaglifo(izq, der)
    
    print("\nArchivos generados:")
    print(f" '{SALIDA_NUBE}'    -> Nube de puntos (tema de clase)")
    print(f" '{SALIDA_MALLA}'   -> Malla triangular (tema de clase)")
    print(f" '{SALIDA_ANAGLIFO}'-_> Imagen para impresion pop-up")

if __name__ == "__main__":
    main()

